window.addEventListener('load', function() {
    var heading1El = document.querySelector('h1');
    console.log(heading1El);
});