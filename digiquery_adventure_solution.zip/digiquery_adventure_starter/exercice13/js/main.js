// var heading1El = null;
// function onBtnClicked() {
//     heading1El.style.color = 'red';
// }
// function init() {
//     heading1El = document.querySelector('h1');
//     var btnEl = document.querySelector('button');
//     btnEl.addEventListener('click', onBtnClicked);
// }

// window.onload = init;




///

document.querySelector('button').onclick = function() {
    document.querySelector('h1').style.color = 'red';
}