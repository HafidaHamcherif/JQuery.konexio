function init() {
    var spanEl = document.createElement('span');
    spanEl.textContent = "Konexio";
    console.log(spanEl);
}

window.onload = init;