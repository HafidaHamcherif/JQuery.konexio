var btnEl = null;
var btnEl2 = null;
function onBtnClicked() {
    console.log('button clicked');
    this.textContent = 'btn clicked';
}

window.addEventListener('load', function() {
    btnEl = document.querySelectorAll('button')[0];
    btnEl2 = document.querySelectorAll('button')[1];
    btnEl.addEventListener('click', onBtnClicked);
    btnEl2.addEventListener('click', onBtnClicked);
});