window.addEventListener('load', function() {
    var heading2El = document.querySelector('h2');
    heading2El.style.backgroundColor = 'green';
    console.log(heading2El);
});