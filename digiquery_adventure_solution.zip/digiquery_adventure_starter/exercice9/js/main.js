function init() {
    var divEl = document.createElement('div');
    console.log(divEl);
}

window.addEventListener('load', init);