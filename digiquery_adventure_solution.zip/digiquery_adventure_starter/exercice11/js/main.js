function init() {
    var pEl = document.createElement('p');
    pEl.textContent = "Konexio";
    console.log(pEl);
    var bodyEl = document.querySelector('#exercise');
    bodyEl.appendChild(pEl);
}

window.onload = init;