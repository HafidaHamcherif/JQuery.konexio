window.addEventListener('load', function() {
    var heading1El = document.querySelector('h1');
    heading1El.style = 'color: red';
    // heading1El.setAttribute('style', 'color: red');
    console.log(heading1El.style);
    // heading1El.style // read/write
    // heading1El.style.color = 'blue'
});