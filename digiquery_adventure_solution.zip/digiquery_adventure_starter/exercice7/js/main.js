function init() {
    var bodyEl = document.querySelector('body');
    console.log(bodyEl);
}

window.addEventListener('load', init);