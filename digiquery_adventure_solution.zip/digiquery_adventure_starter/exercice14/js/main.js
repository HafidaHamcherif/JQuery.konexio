// window.addEventListener('load', function() {
//     var btnEl = document.querySelector('button');
//     btnEl.addEventListener('click', function() {
//         var heading1El = document.querySelector('h1');
//         heading1El.classList.add('highlight');
//     });
// });

//
document.querySelector('button').onclick = function() {
    document.querySelector('h1').classList.add('highlight')
}