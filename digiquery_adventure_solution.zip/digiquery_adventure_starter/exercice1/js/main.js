window.addEventListener('load', function() {
    console.log('Hello world!');
});
console.log('Hello world2!');