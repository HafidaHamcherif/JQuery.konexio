window.addEventListener('load', function() {
    var heading1El = document.querySelector('h1');
    // heading1El.style = 'color: blue; font-size: 2em';
    // heading1El.setAttribute('style', 'color: blue; font-size: 2em')
    heading1El.style.color = 'blue';
    heading1El.style.fontSize = '2em';

});